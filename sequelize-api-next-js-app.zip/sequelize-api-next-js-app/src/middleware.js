import { NextResponse } from 'next/server'

export default function middleware (request) {
    // if (request.nextUrl.pathname.startsWith('/user')) {
    //     return NextResponse.rewrite(new URL('/', request.url))
    //   }
     
      // if (request.nextUrl.pathname.startsWith('/user')) {
      //   return NextResponse.redirect(new URL('/', request.url))
      // }
}